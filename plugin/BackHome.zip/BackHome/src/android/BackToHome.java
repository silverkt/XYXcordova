package com.hxsmart.BackToHomePlugin;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaArgs;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.PluginResult;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class BackToHome extends CordovaPlugin{
	private String ACTION_BACKTOHOME = "BackToHome";
	private Activity context ;
	@Override
	public boolean execute(String action, CordovaArgs args, CallbackContext callbackContext) throws JSONException {
		System.out.println("exec !!!!!!!"+action);
		context = cordova.getActivity();
		if (ACTION_BACKTOHOME.equals(action)) {
			backToHome(args, callbackContext);
		}
		return true;
	}	
	private void backToHome(final CordovaArgs args, final CallbackContext callbackContext) throws JSONException{
		Intent startMain = new Intent(Intent.ACTION_MAIN); 
	    startMain.addCategory(Intent.CATEGORY_HOME); 
	    startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
	    context.startActivity(startMain); 
	}	
}	