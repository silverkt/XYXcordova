var exec = require("cordova/exec");
function BackToHome() {};
BackToHome.prototype.backToHome = function (successCallback, errorCallback,param) {
	if (errorCallback == null) {
		errorCallback = function () {
		};
	}
	if (typeof errorCallback != "function") {
		console.log("HXiMate.swipeCard failure: failure parameter not a function");
		return;
	}

	if (typeof successCallback != "function") {
		console.log("HXiMate.swipeCard failure: success callback parameter must be a function");
		return;
	}
	exec(successCallback, errorCallback, 'BackToHome', 'BackToHome', [param]);
};
module.exports = new BackToHome();